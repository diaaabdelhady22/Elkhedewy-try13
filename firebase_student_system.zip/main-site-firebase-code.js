// بدل الكود القديم اللي فيه names[code]
// حط الكود دا داخل الصفحة الأساسية

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
getFirestore,
doc,
getDoc
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
apiKey: "AIzaSyAP0yi9cxRUfhATG7n9yZ5GvEwvprrcY_E",
authDomain: "admin-bc778.firebaseapp.com",
projectId: "admin-bc778",
storageBucket: "admin-bc778.firebasestorage.app",
messagingSenderId: "506982106111",
appId: "1:506982106111:web:b73205f62c722bc0121dca"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function getStudent(code){

const studentRef = doc(db,"students",code);
const studentSnap = await getDoc(studentRef);

if(!studentSnap.exists()){
alert("الطالب غير موجود");
return;
}

const data = studentSnap.data();

if(!data.active){
alert("الطالب متوقف");
return;
}

console.log("اسم الطالب:",data.name);

// هنا حط أي حاجة كانت بتشتغل بالاسم
}
